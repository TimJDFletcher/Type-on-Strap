#!/bin/sh
pwd=$(pwd)
src=/usr/src/git/ipxe/src

cd $src
git pull
make bin/ipxe.lkrn
cp $src/bin/ipxe.lkrn $pwd/ipxe.krn
